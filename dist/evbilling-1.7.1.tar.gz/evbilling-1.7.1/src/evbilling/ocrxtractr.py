'''
Abstract base class definitions for OCR of PDF file

Geometry structure in doctr.io Word, Line, Artefact, and Block classes
are all based on the same structure.  The Geometry class is used to
represent the bounding box of a block in the image, defined by its top-left
and bottom-right corners.  The coordinates are normalized to the dimensions
of the image, making them resolution-independent.
'''

__author__ = 'Keith Gorlen'

import sys
import logging
from pathlib import Path
from abc import ABC, abstractmethod
from collections import namedtuple
import re
from itertools import zip_longest
from typing import Any


SCRIPT_DIR: Path = Path(__file__).absolute().parent
"""Path to directory containing this Python script."""
sys.path.append(str(SCRIPT_DIR))
"""Allow evbilling CLI to import modules from script directory."""

# pylint: disable=wrong-import-position

from __init__ import __version__
from evargs import Args
from rapidfuzz.distance.Levenshtein import normalized_distance

# pylint: enable=wrong-import-position

#
# Global constants
#

logger = logging.getLogger(f'evbilling.{__name__}')

Point = namedtuple('Point', 'x y')


class Geometry:
    """docTR block geometry.

    Notes
    -----
    In Python docTR, geometry coordinates are typically measured as
    normalized values relative to the dimensions of the image they are
    extracted from. This means that coordinates are expressed as fractions
    of the width and height of the image, ranging from 0 to 1. This approach
    allows the coordinates to be resolution-independent, making it easier to
    work with images of different sizes.

    """

    def __init__(self, tl: Point, br: Point) -> None:
        """Initialize block geometry instance.

        Parameters
        ----------
        tl : Point
            x-y coordinates of block top left
        br : Point
            x-y coordinates of block bottom right

        """
        self.tl = tl
        self.br = br

    def __str__(self) -> str:
        """Return block Geometry as string."""
        return f'tl=({self.tl.x:.4f},{self.tl.y:.4f}) br=({self.br.x:.4f},{self.br.y:.4f})'


class OCRXtractr(ABC):
    """Abstract base class definitions for OCR of PDF file."""

    counters = {
        # Number of lines corrected.
        'lines corrected': 0,
        # Number of digit location corrections.
        'digit location corrections': 0,
        # Number of repeated digit corrections.
        'repeated digit corrections': 0,
        # Number of digit misclassification errors.
        'digit misclassification errors': 0,
        # Number of digit misclassification corrections.
        'digit misclassification corrections': 0,
        # Number of lines with normalized Levenshtein distance > Args.maxscore
        # or no letters or slashes.
        'lines skipped': 0,
        # Total lines
        'lines total': 0,
    }
    """Counters for various statistics."""

    max_score: float = 0
    """Maximum normalized Levenshtein distance of lines corrected by fuzzy matching."""
    min_score: float = 9999
    """Minimum normalized Levenshtein distance > Args.maxscore of skipped lines."""
    min_score_line: str = ''
    """Skipped line with minimum normalized Levenshtein distance > Args.maxscore."""

    @classmethod
    def reset_counters(cls) -> None:
        """Reset counters."""
        for key in cls.counters:
            cls.counters[key] = 0

    def __init__(self) -> None:
        self.ps_w: int
        """Page width in pixels as measured in Photoshop."""
        self.ps_h: int
        """Page height in pixels as measured in Photoshop."""
        self.line_h: float
        """Minimum distance between lines as measured in Photoshop."""
        self.delta_y_threshold: float
        """Vertical distance threshold in pixels for words in the same line."""
        self.block_geometries: dict[str, Geometry]
        """Parts of page to extract."""
        self.page_block_names: tuple[tuple[str, ...], ...]
        """page_block_names[page_num] = tuple(keys of block_geometries on page_num)"""
        self.templates: dict[str, tuple[str, list[str], int]] = {}
        """templates[template] = (item_id: str, non_nums: list[str], num_count: int)"""
        self.max_dy = 0
        """Maximum delta-y of line y coordinates."""
        self.max_dy_text: str = ''
        """Text of line with maximum delta-y."""

    def init_templates(self, line_item_templates: str) -> None:
        """Initialize templates with line items from expected_line_items.

        Parameters
        ----------
        line_items : str
            Correction patterns for line items in OCR text: ^ indicates digit,
            initial # indicates comment, initial + indicates continuation.
            Number of consecutive ^s is not significant.  Templates containing
            both constant digits and digit variables are not supported.
        """
        for template in line_item_templates.splitlines():
            if not template or template[0] == '#':
                # Skip blank lines and comments.
                continue

            if template[0:4] == '=== ':
                continue  # Section header or footer.

            item_id: str = ''.join(
                re.findall(r'[a-zA-Z/]+', template)
            )  # Include "/" for mm/dd/yyyy
            non_nums: list[str] = re.findall(r'[^^]+', template)
            if template[0] == '^':
                non_nums = [''] + non_nums

            num_count: int = len(
                re.findall(r'\^+', template)
            )  # Number of number parts expected in the line.

            self.templates[template] = (item_id, non_nums, num_count)

    @abstractmethod
    def auto_geometry(self, lines: list[Any]) -> None:
        """Set block geometries based on OCR text position.

        Parameters
        ----------
        line : list[Line]
            List of doctr.io Line instances on a page.
        """
        return

    @abstractmethod
    def correct_digit_location_errors(self, line: str) -> str:
        """Correct digit location detection errors in OCR text.

        Parameters
        ----------
        line : str
            OCR text of line.

        Returns
        -------
        str
            Corrected line of text.
        """
        return line

    @abstractmethod
    def correct_digit_misclassification_errors(
        self, line: str, non_nums: list[str], num_count: int, line_nums: list[str]
    ) -> list[str]:
        """Correct digit misclassification errors.

        Parameters
        -----------
        line : str
            The line of OCR text with location errors corrected.
        non_nums : list[str]
            The expected non-numeric parts of the line.
        num_count : int
            The expected number of numeric parts in the line.
        line_nums : list[str]
            The numeric parts actually found in the line.

        Returns
        -------
        list[str]
            Corrected list of number parts in the line.
        """
        return line_nums

    def correct_text(self, text: str) -> str:
        """
        Correct OCR text using fuzzy matching.

        Parameters
        -----------
        text : str
            The OCR text to correct.

        Returns
        --------
        str
            The corrected OCR text.

        Notes
        -----
        References:
        https://medium.com/codex/best-libraries-for-fuzzy-matching-in-python-cbb^e^ef^^dd
        """

        def correct_line(non_nums: list[str], line_nums: list[str]) -> str:
            """Correct a line of text.

            Parameters
            -----------
            non_nums : list[str]
                The expected non-numeric parts of the line.
            line_nums : list[str]
                The numeric parts actually found in the line.

            Returns
            --------
            str
                The corrected line of text.
            """
            return ''.join([s + n for s, n in zip_longest(non_nums, line_nums, fillvalue='')])

        corrected_text: list[str] = []
        """List of corrected lines."""
        last_line_numbers: list[str] = []
        """List to store the numeric parts of the previous line."""
        last_closest_key: str = ''
        """The closest template key found for the previous line."""

        for line in text.splitlines(keepends=True):
            line = line.strip()

            if not line:
                continue

            if len(line) >= 4 and line[0:4] == '=== ':
                # No need to correct lines not from OCR.
                corrected_text.append(line)
                continue

            corrected_line: str = line
            """Corrected line of text."""
            line_item_id: str = ''.join(re.findall(r'[a-zA-Z/]+', corrected_line))
            """"All the letters and "/"s in the line ("/"s included for mm/dd/yyyy dates)."""
            low_score: float = 9999  # Arbitrarily high score for normalized distance
            """Minimum number of changes required to transform OCR text to expected text."""
            closest_key: str = ''
            """Template key of closest matching line item."""

            if not line_item_id:
                logger.debug(f"Skipping line with no letters: {line}")
                OCRXtractr.counters['lines skipped'] += 1
                continue

            for key, (item_id, non_nums, num_count) in self.templates.items():
                score: float = normalized_distance(line_item_id, item_id)
                if score < low_score:
                    low_score = score
                    closest_key = key

            assert closest_key, 'No closest template key found'

            if low_score > Args.maxscore:  # Threshold for fuzzy matching
                logger.debug(f"Skipping line with score {low_score:.2f} > {Args.maxscore}: {line}")
                OCRXtractr.counters['lines skipped'] += 1
                if low_score < OCRXtractr.min_score:
                    OCRXtractr.min_score = low_score
                    OCRXtractr.min_score_line = line
                continue

            OCRXtractr.max_score = max(OCRXtractr.max_score, low_score)

            non_nums: list[str] = self.templates[closest_key][1]
            """Non-number parts in the closest key."""
            num_count: int = self.templates[closest_key][2]
            """Number of number parts expected in the line."""
            line_nums: list[str] = []
            """All the number parts in the line."""

            if num_count > 0:
                corrected_line = self.correct_digit_location_errors(line)
                # Accept thousands separator commas in number parts
                line_nums: list[str] = re.findall(r'(\d+(?:,?\d{3})*)', corrected_line)

                if len(line_nums) != num_count:
                    # Number of number parts found not as expected
                    line_nums = self.correct_digit_misclassification_errors(
                        line, non_nums, num_count, line_nums
                    )

                corrected_line: str = correct_line(non_nums, line_nums)
            else:  # No variable numbers in the template
                corrected_line = closest_key

            # If the closest key is a continuation, append the current line to the
            # first non-number part of the last line, which handles the special case
            # of "Generation - Super Off Peak - <Summer | Winter>".
            #
            # Could generalize by +n at beginning, where n is index of non-number
            # part to append to.

            if closest_key[0] == '+':
                corrected_text.pop()
                non_nums: list[str] = (
                    [self.templates[last_closest_key][1][0] + non_nums[0][1:]]
                    + non_nums[1:]
                    + self.templates[last_closest_key][1][1:]
                )
                corrected_line = correct_line(
                    non_nums,
                    last_line_numbers + line_nums,
                )

            if corrected_line != line:
                logger.info(f'OCR:  {line}')
                ndist = f'{low_score:.2f}'[1:] if low_score < 1 else f'{low_score:.1f}'
                logger.info(f'{ndist}-> {corrected_line}')
                OCRXtractr.counters['lines corrected'] += 1

            corrected_text.append(corrected_line)
            last_line_numbers = line_nums
            last_closest_key = closest_key

        return '\n'.join(corrected_text) + '\n'

    def assemble_page(self, page_num: int, page, block_names: tuple[str, ...]) -> str:
        """Assemble the words in blocks into lines and lines into a page.

        Parameters
        ----------
        xtr: OCRXtractr
            The OCRXtractr instance for the PDF file.
        page_num : int
            Page number of bill file.
        page : docTR page object
            Page object from docTR.
        block_names : tuple[str, ...]
            List of names of blocks to extract from the page.

        Returns
        -------
        str
            Extracted text from the page.

        Raises
        ------
        ValueError
            Page n: ocr_predictor(resolve_blocks=False) returned n blocks.
        LookupError
            ocr_predictor(resolve_blocks=False) returned no blocks.

        Notes
        -----
        A DocTR Word = namedtuple('Word', 'value page geometry')

        """
        ocr_text: str = ''
        """Extracted text."""

        # Resolve_blocks=False should return one block

        if len(page.blocks) > 1:
            raise ValueError(
                f'ocr_predictor(resolve_blocks=False) ' f'returned {len(page.blocks)} blocks'
            )

        if len(page.blocks) == 0:
            raise LookupError('ocr_predictor(resolve_blocks=False) returned no blocks')

        for block_name in block_names:
            block: Geometry = self.block_geometries[block_name]
            """Geometry of named block."""

            ocr_text += f"=== Page {page_num} {block_name} ===\n"

            words: list[Any] = sorted(
                (
                    word
                    for line in page.blocks[0].lines
                    for word in line.words
                    if (
                        block.tl.x <= word.geometry[0][0] <= block.br.x
                        and block.tl.y <= word.geometry[0][1] <= block.br.y
                        and block.tl.x <= word.geometry[1][0] <= block.br.x
                        and block.tl.y <= word.geometry[1][1] <= block.br.y
                    )
                ),
                key=lambda word: word.geometry[0][1],
            )
            """words = list of all words in a block on the page sorted by y coordinate"""

            if len(words) == 0:
                ocr_text += '<NONE>\n'
                continue

            # Reorganize the words in a block into lines

            current_words = [words[0]]
            for word in words[1:] + [None]:
                # Check if the current word is part of the last line vertically
                if (
                    word is not None
                    and abs(word.geometry[0][1] - current_words[-1].geometry[0][1])
                    < self.delta_y_threshold
                ):
                    current_words.append(word)  # Extend current line
                else:  # End of a line
                    ordered_words = sorted(current_words, key=lambda w: w.geometry[0][0])
                    linetext = f'{" ".join(word.value for word in ordered_words)}'
                    ocr_text += linetext + '\n'
                    OCRXtractr.counters['lines total'] += 1
                    current_words = [word]  # Start a new line

                    if len(ordered_words) > 1:  # Track the max delta-y seen in all lines
                        word_y = [word.geometry[0][1] for word in ordered_words]
                        dy = max(abs(ay - by) for ay, by in zip(word_y, word_y[1:]))
                        if dy > self.max_dy:
                            self.max_dy, self.max_dy_text = dy, linetext

        return ocr_text
