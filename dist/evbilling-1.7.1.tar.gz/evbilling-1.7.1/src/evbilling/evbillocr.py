'''
evbillocr -- Extract text from selected pages of the PDF bill file.

See https://mindee.github.io/doctr/latest/using_doctr/using_models.html

Location detection model test results:

Default det_arch = 'fast_base' fails on --pages 35 2318custbill07162024.pdf:
    Generation Generation - - Off On Peak Peak - - Winter Summer 0.000000 0.000000 kWh \
        kWh @ $0.0 $0.23725 08035 0.00 0.00

2025-07-05 18:46:36 - INFO - location detection model: db_resnet34, recognition model: crnn_vgg16_bn
2025-07-05 18:46:36 - INFO - bin_thresh: 0.3, box_thresh: 0.1, dpi: 1200, max_score: 0.200
2025-07-05 18:46:36 - INFO -  135 lines corrected
2025-07-05 18:46:36 - INFO -    1 digit location corrections
2025-07-05 18:46:36 - INFO -   39 repeated digit corrections
2025-07-05 18:46:36 - INFO -    0 digit misclassification errors
2025-07-05 18:46:36 - INFO -    0 digit misclassification corrections
2025-07-05 18:46:36 - INFO -   88 lines skipped
2025-07-05 18:46:36 - INFO -  681 lines total
2025-07-05 18:46:36 - INFO - 20% lines corrected
2025-07-05 18:46:36 - INFO - Maximum normalized Levenshtein distance
    of lines corrected by fuzzy matching: 0.077
2025-07-05 18:46:36 - INFO - Skipped line with minimum normalized Levenshtein distance (0.567):
    "New rates for CleanPowerSF generation service went into effect on July 1, 2024."

2025-07-05 18:53:33 - INFO - location detection model: db_resnet50, recognition model: crnn_vgg16_bn
2025-07-05 18:53:33 - INFO - bin_thresh: 0.3, box_thresh: 0.1, dpi: 1200, max_score: 0.200
2025-07-05 18:53:33 - INFO -  147 lines corrected
2025-07-05 18:53:33 - INFO -    0 digit location corrections
2025-07-05 18:53:33 - INFO -    2 repeated digit corrections
2025-07-05 18:53:33 - INFO -    4 digit misclassification errors
2025-07-05 18:53:33 - INFO -    4 digit misclassification corrections
2025-07-05 18:53:33 - INFO -   88 lines skipped
2025-07-05 18:53:33 - INFO -  681 lines total
2025-07-05 18:53:33 - INFO - 22% lines corrected
2025-07-05 18:53:33 - INFO - Maximum normalized Levenshtein distance of
    lines corrected by fuzzy matching: 0.143
2025-07-05 18:53:33 - INFO - Skipped line with minimum normalized Levenshtein distance (0.567):
    "New rates for CleanPowerSF generation service went into effect on July 1, 2024."    

2025-07-04 14:08:22 - INFO - location detection model: db_mobilenet_v3_large, 
    recognition model: crnn_vgg16_bn
2025-07-04 14:08:22 - INFO - bin_thresh: 0.3, box_thresh: 0.1, dpi: 1200, max_score: 0.200
2025-07-04 14:08:22 - INFO -  143 lines corrected
2025-07-04 14:08:22 - INFO -    6 digit location corrections
2025-07-04 14:08:22 - INFO -    4 repeated digit corrections
2025-07-04 14:08:22 - INFO -    0 digit misclassification errors
2025-07-04 14:08:22 - INFO -    0 digit misclassification corrections
2025-07-04 14:08:22 - INFO -   91 lines skipped
2025-07-04 14:08:22 - INFO -  684 lines total
2025-07-04 14:08:22 - INFO - 21% lines corrected
2025-07-04 14:08:22 - INFO - Maximum normalized Levenshtein distance of 
    lines corrected by fuzzy matching: 0.077
2025-07-04 14:08:22 - INFO - Skipped line with minimum normalized Levenshtein distance (0.567): 
    "New rates for CleanPowerSF generation service went into effect on July 1, 2024."

evbilling fails processing multiple bills w/ db_mobilenet_v3_large:
    RuntimeError: main thread is not in main loop
    Exception ignored in: <function Variable.__del__ at 0x0000029AD5CC9120>
    Traceback (most recent call last):
    File "C:\\Python312\\Lib\\tkinter\\__init__.py", line 414, in __del__
        if self._tk.getboolean(self._tk.call("info", "exists", self._name)):
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    RuntimeError: main thread is not in main loop
    Tcl_AsyncDelete: async handler deleted by the wrong thread

det_arch = 'linknet_resnet18' fails on 2318custbill08142024.pdf:
    Subscription Level (10kW/block) 10 blocks @ . 0000 month

det_arch = 'linknet_resnet34' fails on 2318custbill08142024.pdf:
    Generation Super Off Peak 2.977500 kWh @ 3 $0.06518 $0.19

det_arch = 'linknet_resnet50' fails on 2318custbill08142024.pdf:
    Overage Fees kW @ $2.48000 0.00
    Franchis e Fee Surcharge 0.01

det_arch = 'fast_tiny' fails on 2318custbill10072024.pdf:
    Subscription Level (10kW/block) 1 block @ 0.7333 month @ $ 12.41 $9.10
    10/01/2024 -  -1 10/31/2024

det_arch = 'fast_small' fails on 2318custbill11072024.pdf:
    10/01/2024 -  - 10 0/31/2024
    Peak 3.363000 kWh @ 3 $0.38372 1.29
    10/01/2024 -  - 1 0/31/2024
'''

__author__ = 'Keith Gorlen'

import os
import sys
import logging
from pathlib import Path
import io
from typing import Any


SCRIPT_DIR: Path = Path(__file__).absolute().parent
"""Path to directory containing this Python script."""
sys.path.append(str(SCRIPT_DIR))
"""Allow evbilling CLI to import modules from script directory."""

# pylint: disable=wrong-import-position

from __init__ import __version__
from evargs import Args, pge_pdf_bill_paths
from evlogger import DATE_FMT, info_msg
from ocrxtractr import OCRXtractr
from ocrbev1 import OCRBEV1
import numpy as np

# pylint: enable=wrong-import-position

#
# Global constants
#

logger = logging.getLogger(f'evbilling.{__name__}')

#
# Global variables
#

Model: Any = None
"""Global variable for the docTR OCR model instance."""


def extract_text(
    xtr: OCRXtractr,
    page_nums: list[int],
    bill_path: Path,
    out_subdir: Path,
    force_ocr: bool | None = None,
    show_ocr: bool = False,
) -> list[str]:
    """Extract text from selected pages of the PDF bill file.

    Parameters
    ----------
    xtr: OCRXtractr
        The OCRXtractr instance for the PDF file.
    page_nums: list[int]
        List of page numbers from which to extract text.
    bill_path : Path
        Path of PG&E bill PDF file.
    out_subdir : Path
        Path of output directory.
    force_ocr : bool | None, optional
        Force OCR even if sidecar file exists, by default None (OCR OK if no sidecar)
    show_ocr : bool, optional
        Show OCR result; implies --forceocr, by default False

    Returns
    -------
    list[str].
        OCR text of the specified PDF pages.

    Raises
    ------
    LookupError
        Sidecar file not found
    ValueError
        Page number out of range 1 to number of pages in document.
    ValueError
        Page n: ocr_predictor(resolve_blocks=False) returned n blocks
    LookupError
        ocr_predictor(resolve_blocks=False) returned no blocks

    Notes
    -----
    OCR text from a billfile-OCR.txt sidecar file is used if it exists. Correct
    OCR errors by manually editing the sidecar file and rerunning evbilling.py.
    """
    global Model  # pylint: disable=global-statement

    # Check for sidecar text file

    sidecar_path: Path = out_subdir.joinpath(bill_path.stem + '-OCR.txt')
    """Path of sidecar text file."""
    sidecar_text: str = ''
    """Text from sidecar file."""
    scale: int = round(Args.dpi / 96)
    """Scale factor for rendering PDF pages at Args.dpi DPI."""

    if 0 in page_nums:
        raise ValueError('Page number 0 out of range')

    if not (force_ocr or show_ocr):

        try:
            with open(sidecar_path, encoding='utf-8') as ocrtextfile:
                logger.info(f'Reading OCR text from sidecar file {sidecar_path} ...')
                sidecar_text = ocrtextfile.read()
                info_msg(logger, f'Using OCR text from sidecar file {sidecar_path}.')
                return sidecar_text.split('\f')

        except IOError as err:
            logger.debug(f'{err} in open({sidecar_path}), running OCR ...')

    if not sidecar_text and force_ocr is False and not show_ocr:
        raise LookupError(f'{sidecar_path} sidecar file not found; OCR required')

    corrected_text: list[str] = []
    """Corrected text."""

    logger.info(f'Running OCR on {bill_path} ...')

    # db_mobilenet_v3_large is not compatible with matplotlib interactive mode
    if Args.detarch == 'db_mobilenet_v3_large' and not show_ocr:
        import matplotlib  # pylint: disable=import-outside-toplevel

        matplotlib.use('Agg')
        logger.info('Using matplotlib non-interactive Agg backend.')

    logger.info('Importing pypdfium2 ...')
    from pypdfium2 import PdfDocument  # pylint: disable=import-outside-toplevel

    logger.info('Importing doctr.io ...')
    from doctr.io import DocumentFile  # pylint: disable=import-outside-toplevel

    logger.info('Importing doctr.models ...')
    from doctr.models import ocr_predictor  # pylint: disable=import-outside-toplevel

    logger.info(f'Python DocTR detection model: {Args.detarch}, recognition model: {Args.recoarch}')

    # pylint: disable=possibly-used-before-assignment (E0606)
    if not Model:
        Model = ocr_predictor(
            det_arch=Args.detarch, reco_arch=Args.recoarch, pretrained=True, resolve_blocks=False
        )

    if Args.binthresh is not None:
        Model.det_predictor.model.postprocessor.bin_thresh = Args.binthresh
    if Args.boxthresh is not None:
        Model.det_predictor.model.postprocessor.box_thresh = Args.boxthresh
    logger.info(
        f'bin_thresh: {Model.det_predictor.model.postprocessor.bin_thresh}, '
        f'box_thresh: {Model.det_predictor.model.postprocessor.box_thresh}, '
        f'max_score: {Args.maxscore:.3f}, '
        f'dpi: {Args.dpi}, scale: {scale}'
    )

    page_images = []
    pdf_document = PdfDocument(bill_path)

    if max(page_nums) > len(pdf_document):
        raise ValueError(
            f'Page number(s) {", ".join(str(p) for p in page_nums if p > len(pdf_document))} '
            f'out of range'
        )

    # Need to explicitly render pages to control DPI.

    for page_num in page_nums:
        logger.info(f'Rendering page {page_num} ...')
        page = pdf_document[page_num - 1]
        pil_img = page.render(scale=scale).to_pil()
        buf = io.BytesIO()
        pil_img.save(buf, format="PNG")
        page_images.append(buf.getvalue())
        buf.close()
    pdf_document.close()

    doc: list[np.ndarray] = DocumentFile.from_images(page_images)

    ocr_result = Model(doc)
    """Selected pages of bill file."""

    if show_ocr:
        ocr_result.show()  # Show detected locations of words on page

    # Determine text block geometries from locations of key phrases

    if Args.autoblock:
        xtr.auto_geometry(ocr_result.pages[0].blocks[0].lines)

    # Assemble pages of text from blocks

    for page_num, page, block_names in zip(page_nums, ocr_result.pages, xtr.page_block_names):

        try:
            ocr_text = xtr.assemble_page(page_num, page, block_names)
            logger.info(f'Correcting OCR text on page {page_num} ...')
            corrected_text.append(xtr.correct_text(ocr_text))
        except Exception as err:
            raise type(err)(f"Error processing page {page_num} of file {bill_path}: {err}") from err

    logger.info(
        f'Delta-y threshold: {xtr.delta_y_threshold:0.5f}, '
        f'max delta-y: {xtr.max_dy:0.5f} for "{xtr.max_dy_text}".'
    )
    logger.info(
        f'Corrected lines max score: {xtr.max_score:.3f}, '
        f'skipped line min score: {xtr.min_score:.3f} for "{xtr.min_score_line}"'
    )

    logger.info(f'Writing OCR text to sidecar file {sidecar_path} ...')

    with open(sidecar_path, 'w', encoding='utf-8') as ocrtextfile:
        ocrtextfile.write('\f'.join(corrected_text))

    return corrected_text


def main(script_name: str) -> None:
    """Test text extraction from PG&E bill PDF files.

    Parameters
    ----------
    script_name : str
        Name of this script without .py extension.
    """
    Args.init(script_name, __version__)

    logger.info(f'{"=" * 60}')
    logger.info(f'{script_name} version {__version__} starting in {os.getcwd()} ...')
    logger.info(f'{script_name} arguments: {Args.as_string()}.')

    if Args.debug:
        logger.setLevel(logging.DEBUG)

    if Args.outdir is None:
        raise ValueError(
            'Output directory not specified; use --outdir <directory> to specify output directory.'
        )

    assert isinstance(Args.billfiles, list)
    for bill_path in pge_pdf_bill_paths(Args.billfiles):
        bill_file: Path = bill_path.absolute()
        info_msg(logger, f'Processing {bill_file} ...')
        ocr_file_path = Args.outdir / f"{bill_path.stem}-OCR.txt"
        ocrpages: list[str] = extract_text(
            OCRBEV1(), list(divmod(Args.pages, 10)), bill_file, Args.outdir, force_ocr=True
        )  # Extract text pages from bill PDF

        with open(ocr_file_path, 'w', encoding='utf-8') as ocr_file:
            ocr_file.write('\f'.join(ocrpages))

    # Log statistics

    info_msg(
        logger, f'location detection model: {Args.detarch}, recognition model: {Args.recoarch}'
    )
    info_msg(
        logger,
        f'bin_thresh: {Model.det_predictor.model.postprocessor.bin_thresh}, '
        f'box_thresh: {Model.det_predictor.model.postprocessor.box_thresh}, '
        f'dpi: {Args.dpi}, max_score: {Args.maxscore:.3f}'
    )

    for key, count in OCRXtractr.counters.items():
        info_msg(logger, f'{count:4d} {key}')
    info_msg(
        logger,
        f'{OCRXtractr.counters['lines corrected'] / OCRXtractr.counters['lines total']:.0%} '
        f'lines corrected',
    )
    info_msg(
        logger,
        f'Maximum normalized Levenshtein distance of lines corrected by fuzzy matching: '
        f'{OCRXtractr.max_score:.3f}',
    )
    info_msg(
        logger,
        f'Skipped line with minimum normalized Levenshtein distance ({OCRXtractr.min_score:.3f}): '
        f'"{OCRXtractr.min_score_line}"',
    )

    info_msg(logger, f'{script_name} finished.')
    logger.info(f'{"=" * 60}')
    logging.shutdown()
    sys.exit(0)


if __name__ == '__main__':
    from logging.handlers import RotatingFileHandler
    from evsettings import Config

    SCRIPT_NAME: str = Path(__file__).stem
    """Name of this script without .py extension."""
    logger = logging.getLogger(SCRIPT_NAME)
    """Logging facility."""
    rotating_handler = RotatingFileHandler(
        Config.evbilling_log, maxBytes=5 * 1024 * 1024, backupCount=3
    )
    """Rotating log file handler."""
    rotating_handler.setLevel(logging.INFO)
    rotating_handler.setFormatter(
        logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Log format
            datefmt=DATE_FMT,  # Custom date format
        )
    )
    logging.getLogger().addHandler(rotating_handler)

    try:
        main(SCRIPT_NAME)
    except Exception as msg:  # pylint: disable=broad-exception-caught
        """Log a CRITICAL message and sys.exit(1)."""
        logger.critical(f'{msg}; exiting.')
        logger.info(f'{"=" * 60}')
        logging.shutdown()
        sys.exit(1)
