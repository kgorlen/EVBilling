'''
ocrbev1 -- Definitions for OCR of PG&E/CPSF BEV-1 bill.
'''

__author__ = 'Keith Gorlen'

import sys
import logging
from pathlib import Path
import re
from typing import Any


SCRIPT_DIR: Path = Path(__file__).absolute().parent
"""Path to directory containing this Python script."""
sys.path.append(str(SCRIPT_DIR))
"""Allow evbilling CLI to import modules from script directory."""

# pylint: disable=wrong-import-position

from __init__ import __version__
from ocrxtractr import OCRXtractr, Geometry, Point
from evunits import RE_DOLLARS, RE_RATES, Dollars, DollarsPerKilowatt

# pylint: enable=wrong-import-position

#
# Global constants
#


logger = logging.getLogger(f'evbilling.{__name__}')


class OCRBEV1(OCRXtractr):
    """Definitions for OCR of PG&E/CPSF BEV-1 bill."""

    line_item_templates: str = """
# PG&E line items:
=== Page ^ header ===
Account No: ^^^^^^^^^^-^
Statement Date: ^^/^^/^^^^
Due Date: ^^/^^/^^^^
=== Page ^ details ===
Details of PG&E Electric Delivery Charges
^^/^^/^^^^ - ^^/^^/^^^^ (^^ billing days)
Service Agreement ID: ^^^^^^^^^^
Rate Schedule: BEV1 Bus Low Use EV
^^/^^/^^^^ - ^^/^^/^^^^
Subscription Charges
Subscription Level (^^kW/block) ^ block @ ^.^^^^ month @ $^^.^^ $^^.^^
Subscription Level (^^kW/block) ^ blocks @ ^.^^^^ month @ $^^.^^ $^^.^^
Overage Fees ^ kW @ $^.^^^^^ ^^.^^
Energy Charges
Peak ^^.^^^^^^ kWh @ $^.^^^^^ ^^.^^
Off Peak ^^^.^^^^^^ kWh @ $^.^^^^^ ^^.^^
Super Off Peak ^^.^^^^^^ kWh @ $^.^^^^^ ^^.^^
Generation Credit -^^.^^
Power Charge Indifference Adjustment ^^.^^
Franchise Fee Surcharge ^^.^^
San Francisco Utility Users' Tax (^.^^^%) ^^.^^
SF Prop C Tax Surcharge ^^.^^
Total PG&E Electric Delivery Charges $^^.^^
^^^^ Vintaged Power Charge Indifference Adjustment
=== Page ^ service info ===
Service Information
Meter # ^^^^^^^^^^
Total Usage ^^^.^^^^^^ kWh
Rotating Outage Block ^^
=== Page ^ footer ===
Page ^ of ^

# CleanPowerSF line items:
=== Page ^ header ===
Account No: ^^^^^^^^^^-^
Statement Date: ^^/^^/^^^^
Due Date: ^^/^^/^^^^
=== Page ^ details ===
Details of CleanPowerSF Electric Generation Charges
Details of CleanPowerSF Electric Generation 
+Charges
^^/^^/^^^^ - ^^/^^/^^^^ (^^ billing days)
Service Agreement ID: ^^^^^^^^^^ ESP Customer Number: ^^^^^^^^^^
^^/^^/^^^^ - ^^/^^/^^^^
^^/^^/^^^^
Rate Schedule: B-EV-1
Generation - Super Off Peak - ^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
+Summer 
Generation - Super Off Peak - Summer ^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
Generation - Off Peak - Summer ^^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
Generation - On Peak - Summer ^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
Generation - Super Off Peak - ^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
+Winter 
Generation - Super Off Peak - Winter ^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
Generation - Off Peak - Winter ^^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
Generation - On Peak - Winter ^^.^^^^^^ kWh @ $^.^^^^^ $^^.^^
Net Charges ^^.^^
Local Utility Users Tax ^^.^^
Energy Commission Surcharge ^^.^^
Total CleanPowerSF Electric 
+Generation Charges $^^.^^
=== Page ^ footer ===
Page ^ of ^

# Line items for PG&E B1 rate schedule:
Rate Schedule: B1 Bus Low Use
# Line items for CleanPowerSF B-1 rate schedule:
Customer Charge ^^ days @ $^.^^^^^ $^^.^^
Rate Schedule: B-1
"""
    """
    Correction patterns for line items in OCR text: ^ indicates digit, initial #
    indicates comment, initial + indicates continuation.  Number of consecutive
    ^s is not significant.
    """

    def __init__(self) -> None:
        super().__init__()

        self.ps_w: int = 2549
        """Page width in pixels as measured in Photoshop."""
        self.ps_h: int = 3218
        """Page height in pixels as measured in Photoshop."""
        self.line_h: float = 9 / self.ps_h  # pylint: disable=unused-variable
        """Minimum distance between lines as measured in Photoshop."""
        self.delta_y_threshold: float = 20 / self.ps_h
        """Vertical distance threshold in pixels for words in the same line."""

        self.block_geometries: dict[str, Geometry] = {
            # Top-right corner of the page:
            'header': Geometry(tl=Point(1600 / self.ps_w, 0.0), br=Point(1.0, 300 / self.ps_h)),
            # Middle-left part of the page:
            'details': Geometry(
                tl=Point(50 / self.ps_w, 350 / self.ps_h),
                br=Point(1600 / self.ps_w, 2450 / self.ps_h),
            ),
            # Middle-right part of the page, overridden by --autoblock option:
            'service info': Geometry(
                tl=Point(1600 / self.ps_w, 1150 / self.ps_h), br=Point(1.0, 1400 / self.ps_h)
            ),
            # Middle-right part of the page, bills before April 2024:
            # 'service info': Geometry(tl=Point(1600/ps_w, 350/ps_h), br=Point(1.0, 1400/ps_h)),
            # Bottom-right part of the page:
            'footer': Geometry(tl=Point(1600 / self.ps_w, 3000 / self.ps_h), br=Point(1.0, 1.0)),
        }
        """Parts of page to extract."""

        self.page_block_names: tuple[tuple[str, ...], ...] = (
            ('header', 'details', 'service info', 'footer'),  # PG&E page
            ('header', 'details', 'footer'),  # CleanPowerSF page
        )
        """page_block_names[page_num] = tuple(keys of block_geometries on page_num)"""

        # Initialize checker with line items from expected_line_items.
        self.init_templates(OCRBEV1.line_item_templates)

    def auto_geometry(self, lines: list[Any]) -> None:
        """Set block geometries based on OCR text position.

        Parameters
        ----------
        line : list[Line]
            List of doctr.io Line instances on a page.
        """
        for line in lines:
            s: str = ' '.join(word.value for word in line.words)
            if re.search(r'Service Information', s):
                default_geometry = self.block_geometries['service info']
                logger.info(f'Service Information block default location {default_geometry}.')
                line_geometry = Geometry(tl=Point(*line.geometry[0]), br=Point(*line.geometry[1]))
                block_h = default_geometry.br.y - default_geometry.tl.y
                self.block_geometries['service info'] = Geometry(
                    tl=Point(default_geometry.tl.x, line_geometry.tl.y),
                    br=Point(1.0, line_geometry.br.y + block_h),
                )
                logger.info(
                    f'Service Information block location set to '
                    f'{self.block_geometries["service info"]}.'
                )

    def correct_digit_location_errors(self, line: str) -> str:
        """Correct digit location detection errors in OCR text.

        Parameters
        ----------
        line : str
            OCR text of line.

        Returns
        -------
        str
            Corrected line of text.
        """
        re_decimal_space = re.compile(r'(\d\. \d)')
        """Space between decimal point and digit: 1. 23 -> 1.23."""
        # Just count these -- corrected by OCRXtractr.correct_text()
        OCRXtractr.counters['repeated digit corrections'] += len(re.findall(re_decimal_space, line))

        re_repdigit = re.compile(r'(\d\.)(\d) \2')
        """Space and repeated digit after decimal point: 1.2 23 -> 1.23."""

        if re.search(re_repdigit, line):
            OCRXtractr.counters['digit location corrections'] += len(re.findall(re_repdigit, line))
            return re.sub(re_repdigit, r'\1\2', line)

        return line

    def correct_digit_misclassification_errors(
        self, line: str, non_nums: list[str], num_count: int, line_nums: list[str]
    ) -> list[str]:
        """Correct digit misclassification errors.

        Parameters
        -----------
        line : str
            The line of OCR text with location errors corrected.
        non_nums : list[str]
            The expected non-numeric parts of the line.
        num_count : int
            The expected number of numeric parts in the line.
        line_nums : list[str]
            The numeric parts actually found in the line.

        Returns
        -------
        list[str]
            Corrected list of number parts in the line.
        """
        # Code to ignore digit misclassification errors would go here.

        OCRXtractr.counters['digit misclassification errors'] += 1

        if (
            non_nums[0] == 'Overage Fees '
            and not re.search(r' \d+ kW', line)
            and (m := re.search(rf'{RE_RATES} {RE_DOLLARS}$', line))
        ):
            # Correct missing/misclassified kW in Overage Fees line
            rate: DollarsPerKilowatt = DollarsPerKilowatt(m.group(1))
            charge: Dollars = Dollars(m.group(2))
            OCRXtractr.counters['digit misclassification corrections'] += 1
            return [str(round((charge / rate).value))] + line_nums

        logger.warning(f'Could not correct digit misclassification errors in line: {line}')
        return line_nums
