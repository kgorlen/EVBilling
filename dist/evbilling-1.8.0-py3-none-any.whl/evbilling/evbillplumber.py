'''
evbillplumber -- Extract text from selected pages of the searchable PDF bill file.
'''
__author__ = 'Keith Gorlen'

import os
import sys
import logging
from pathlib import Path
import io
import re
from typing import Any


SCRIPT_DIR: Path = Path(__file__).absolute().parent
"""Path to directory containing this Python script."""
sys.path.append(str(SCRIPT_DIR))
"""Allow evbilling CLI to import modules from script directory."""

# pylint: disable=wrong-import-position

from __init__ import __version__
from evargs import Args, pge_pdf_bill_paths
from evlogger import DATE_FMT, info_msg
from evfiles import EVFiles
import pdfplumber
from ocrxtractr import OCRXtractr
from ocrbev1 import OCRBEV1

# pylint: enable=wrong-import-position

#
# Global constants
#

logger = logging.getLogger(f'evbilling.{__name__}')

#
# Global variables
#


def extract_searchable_text(

    page_nums: list[int],
    ev_files: EVFiles,
) -> list[str]:
    """Extract text from selected pages of the PDF bill file.

    Parameters
    ----------
    xtr: OCRXtractr
        The OCRXtractr instance for the PDF file.
    page_nums: list[int]
        List of page numbers from which to extract text.
    ev_files: EVFiles
        EVFiles instance

    Returns
    -------
    list[str].
        OCR text of the specified PDF pages.

    Raises
    ------
    LookupError
        Sidecar file not found
    ValueError
        Page number out of range 1 to number of pages in document.
    ValueError
        Page n: ocr_predictor(resolve_blocks=False) returned n blocks
    LookupError
        ocr_predictor(resolve_blocks=False) returned no blocks

    Notes
    -----
    OCR text from a billfile-OCR.txt sidecar file is used if it exists. Correct
    OCR errors by manually editing the sidecar file and rerunning evbilling.py.
    """
    sidecar_path: Path = ev_files.outdir_path('-TXT.txt')
    """Path of sidecar text file."""
    sidecar_text: list[str] = []

    with pdfplumber.open(ev_files.bill_path) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            text = page.extract_text()
            if page_num in page_nums:
                # Replace multiple spaces and tabs with single space
                text = re.sub(r'[ \t]+', ' ', text)
                sidecar_text.append(text)

    logger.info(f'Writing extracted text to sidecar file {sidecar_path} ...')

    with open(sidecar_path, 'w', encoding='utf-8') as textfile:
        textfile.write('\f'.join(sidecar_text))

    return sidecar_text
